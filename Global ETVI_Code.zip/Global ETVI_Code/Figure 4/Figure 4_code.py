# -*- coding: utf-8 -*-
"""
Created on Sat Aug  2 19:00:22 2025

@author: Vicky
"""


import numpy as np
from pyecharts import charts, options
#from snapshot_phantomjs import snapshot
from pyecharts.render import make_snapshot
from pyecharts.commons.utils import JsCode
from pyecharts.options import VisualMapOpts, TitleOpts, LegendOpts
import pandas as pd
from pyecharts.charts import Map
from pyecharts import options as opts
from snapshot_selenium import snapshot

##1.函数：返回颜色参数

def get_pieces_from_intervals(value, name, category):
    if category=='Score':
        # 固定分段边界
        intervals = [(0, 3), (3, 6), (6, 9), (9, 12)]
    
        # 各变量统一使用红色调（4段）
        color_map = {
            'Vulnerability': ["#fee5d9", "#fcae91", "#fb6a4a", "#cb181d"],
            'Sensitivity':   ["#fee5d9", "#fcae91", "#fb6a4a", "#cb181d"],
            'Adaptive':      ["#fee5d9", "#fcae91", "#fb6a4a", "#cb181d"],
            'Exposure':      ["#fee5d9", "#fcae91", "#fb6a4a", "#cb181d"]
        }
    

    elif category=='Rank':
        # 固定分段边界
        intervals = [(0, 6), (6, 12), (12, 18), (18, 24), (24, 30)]
        
        # 各变量统一使用蓝色调（5段）
        color_map = {
            'Vulnerability': ["#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"],
            'Sensitivity':   ["#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"],
            'Adaptive':      ["#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"],
            'Exposure':      ["#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"]
        }
        
    colors = color_map.get(name, ["#f0f0f0"] * len(intervals))
    pieces = []
    for (i, (min_val, max_val)) in enumerate(intervals):
        label = f"[{min_val},{max_val})" if i < len(intervals) - 1 else f"[{min_val},{max_val}]"
        pieces.append({
            "min": min_val,
            "max": max_val,
            "label": label,
            "color": colors[i]
        }) 
    return pieces



##2. 绘制Figure 4

Category_list=['Rank','Score']
list_name=['Vulnerability','Sensitivity','Exposure','Adaptive']

for category in Category_list:
    for name in list_name:
        df = pd.read_excel(f"{category} std.xlsx")  
        df.rename(columns={"Code": "CountryCode"}, inplace=True)
        ##--------------------
        #剔除国家(对化石能源依赖低且以生物燃料为主)------------------------------------------------------------手动选择
        ##-------------------
        df = df[~df['CountryCode'].isin(['ZMB', 'KEN', 'NPL', 'UGA', 'ETH'])]
        
        #将ETVI文件中的国家名转为ISO code,方便后续与地图中国家匹配
        df_code=pd.read_excel("Country code.xlsx",sheet_name='Country code_ETVI')
    
        value = df[name].tolist()
        print(min(value),max(value),name)
        attr = df['CountryCode'].tolist()
        
        #将地图中的国家名转为ISO code,方便后续与ETVI data中国家匹配
        df_map_code=pd.read_excel("Country code.xlsx",sheet_name='Country code_Map')
        suoxie=df_map_code[['Code','CountryCode']]
        name_map = suoxie.set_index('Code').to_dict()['CountryCode']
        
        #因为一开始想在地图中显示每个国家的三维码，所以这里做了一个国家名字匹配对应的name_map
        map0 = Map(init_opts=opts.InitOpts(width="1000px", height="400px", bg_color="white"))
        map0.add("世界地图", data_pair = [list(z) for z in zip(attr, value)], maptype="world",is_map_symbol_show=False,name_map=name_map,
            #layout_center=["45%", "50%"],  # 地图中心位置（X%, Y%），默认是 ["50%", "50%"]
            layout_size="100%"              # 地图大小，默认约85%，可以调小放大
        ) 
        map0.set_series_opts(
            label_opts=options.LabelOpts(is_show=False)
                                                 
        )   
        pieces = get_pieces_from_intervals(value, name, category)
    
        
        visualmap_opts = opts.VisualMapOpts(
            is_show=True,  
            is_piecewise=True,
            pieces=pieces,
            orient='vertical',
            pos_left='2%',
            pos_top='39%',
            item_width=0.1,       # 隐藏自带色块
            item_height=0.1,      # 同上
            textstyle_opts=opts.TextStyleOpts(color="transparent"),  # 隐藏标签
            border_color="white",  # 或与背景同色
            background_color="white"  # 避免有残留框线
        )
    
        # 对pieces按min排序
        pieces_sorted = sorted(pieces, key=lambda x: x["min"])
    
        # 位置参数
        left_px = 72             # 与 title 左对齐
        start_top_px = 210      
        gap_top_px = 28
        block_width = 22
        block_height = 13
        
        # manual legend - flexible
        graphic_items = []
        
        if max(value)>9:
            flag=4
        elif max(value)>6:
            flag=3
        elif max(value)>3:
            flag=2
        else:
            flag=1
    
        for i, piece in enumerate(pieces_sorted):
            if i+1<=flag:
                top_position = start_top_px + i * gap_top_px
            
                # 添加色块（矩形）
                graphic_items.append({
                    "type": "rect",
                    "left": f"{left_px - 20}px",  # 色块放左边
                    "top": f"{top_position}px",
                    "shape": {
                        "width": block_width,
                        "height": block_height
                    },
                    "style": {
                        "fill": piece["color"],
                        "stroke": "black",  # 可选：边框颜色
                        "lineWidth": 0.1     # 可选：边框宽度
                    },
                    "z": 100,
                })
            
                # 添加对应文字
                graphic_items.append({
                    "type": "text",
                    "left": f"{left_px+10}px",
                    "top": f"{top_position-2}px",
                    "style": {
                        "text": piece["label"],
                        "fill": "black",
                        "font": "18px Times New Roman",
                    },
                    "z": 100,
                })
            else:
                break
            
    
        # 添加顶部居中大标题
        if name!='Adaptive':
            title_main = name+' - '+category
        else:
            title_main = name+" Capacity"+' - '+category
        graphic_items.append({
            "type": "text",
            "left": "center", 
            "top": "2%",       
            "style": {
                "text": title_main,  
                "fill": "black",
                "font": "bold 30px Times New Roman",
                "textAlign": "center",
            },
            "z": 100,
        })
    
        if name == 'Vulnerability':
            label = 'a'
        elif name == 'Exposure':
            label = 'c'
        elif name == 'Sensitivity':
            label = 'e'
        elif name == 'Adaptive':
            label = 'g'
        
        ## Serial number
        graphic_items.append({
            "type": "text",
            "left": "5%",          # 左上角，稍微偏左一点
            "top": "2%",           # 距离顶部2%
            "style": {
                "text": label,
                "fill": "black",
                "font": "bold 35px Times New Roman",
                "textAlign": "left",
            },
            "z": 100,
        })
        map0.set_global_opts(
            visualmap_opts=visualmap_opts,
            graphic_opts=graphic_items,
            legend_opts=opts.LegendOpts(is_show=False),
            title_opts=opts.TitleOpts(
                title=f"\n {category} std",  
                pos_left="4%",  
                pos_top="39%",   
                title_textstyle_opts=opts.TextStyleOpts(
                    font_size=20,
                    font_family='Times New Roman',
                    font_weight='bold',
                    color='black'
                )
            ),
    
        )
    
        
    
        # Render the map to an HTML file
        html_file = f"Figure_4//Figure 4_{category}-"+name+".html"
        map0.render(html_file)
        make_snapshot(snapshot,html_file, f"Figure_4//Figure 4_{category}-"+name+".png", pixel_ratio=3)
    
##3. 拼接Figure 4
from PIL import Image
##Merge images
img5 = Image.open("Figure_4//Figure 4_Rank-Vulnerability.png")
img7 = Image.open("Figure_4//Figure 4_Rank-Sensitivity.png")
img6 = Image.open("Figure_4//Figure 4_Rank-Exposure.png")
img8 = Image.open("Figure_4//Figure 4_Rank-Adaptive.png")


img1 = Image.open("Figure_4//Figure 4_Score-Vulnerability.png")
img3= Image.open("Figure_4//Figure 4_Score-Sensitivity.png")
img2 = Image.open("Figure_4//Figure 4_Score-Exposure.png")
img4 = Image.open("Figure_4//Figure 4_Score-Adaptive.png")

# 确保所有图片尺寸一致（如果你确定是同尺寸的可以跳过这一步）
width, height = img1.size

# 创建一个新图像，宽度为两张图的宽，高度为两张图的高
new_image = Image.new('RGB', (width * 2, height * 4), color=(255, 255, 255))


# 粘贴图片：左列是 Rank，右列是 Score
images_left = [img1, img2, img3, img4]
images_right = [img5, img6, img7, img8]

for i in range(4):
    new_image.paste(images_left[i], (0, i * height))          # Rank 图：左边
    new_image.paste(images_right[i], (width, i * height))     # Score 图：右边

# 保存结果
new_image.save("Figure_4/Figure 4_Combined.png")
