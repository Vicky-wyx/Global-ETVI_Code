# -*- coding: utf-8 -*-
"""
Created on Mon Aug  4 14:19:09 2025

@author: Vicky
"""

import numpy as np
from pyecharts import charts, options
from pyecharts.render import make_snapshot
from pyecharts.options import VisualMapOpts, TitleOpts, LegendOpts
import pandas as pd
from pyecharts.charts import Map
from pyecharts import options as opts
from snapshot_selenium import snapshot
from PIL import Image

##1.函数：返回颜色参数
def get_pieces_from_quantiles(value, name):
    # 确保 value 是数组
    value = np.array(value)
    
    # 基于分位数生成分段边界（共8个点，分成7段）
    quantiles = np.quantile(value, q=np.linspace(0, 1, 8))
    quantiles[0] = quantiles[0]-1   # 强制最小值为0
    quantiles[-1] = quantiles[-1]+1  # 强制最大值为100
    quantiles = np.round(quantiles, 2)  # 保留两位小数

    # 各变量对应的颜色方案（7色）
    color_map = {
        'Vulnerability': ["#f0f9e8", "#ccebc5", "#a8ddb5", "#7bccc4", "#4eb3d3", "#2b8cbe", "#08589e"],
        'Sensitivity':   ["#edf8fb", "#bfd3e6", "#9ebcda", "#8c96c6", "#8c6bb1", "#88419d", "#6e016b"],
        'Adaptive':      ["#ffffcc", "#d9f0a3", "#addd8e", "#78c679", "#41ab5d", "#238443", "#005a32"],
        'Exposure':      ["#fef0d9", "#fdd49e", "#fdbb84", "#fc8d59", "#ef6548", "#d7301f", "#990000"]
    }

    # 生成 pieces 列表
    pieces = []
    colors = color_map.get(name, ["#f0f0f0"] * 7)  # fallback 灰色

    for i in range(len(quantiles) - 1):
        min_val = round(float(quantiles[i]))
        max_val = round(float(quantiles[i + 1]))
        label = f"[{min_val},{max_val})" if i < len(quantiles) - 2 else f"[{min_val},{max_val}]"
        pieces.append({
            "min": min_val,
            "max": max_val,
            "label": label,
            "color": colors[i]
        })

    return pieces


##2. 绘制Figure 2

##读取文件
df = pd.read_csv(r"2025-07-20 Data_Vulnerability.csv")  
df = df[df['Year'] == 2023]

#将ETVI文件中的国家名转为ISO code,方便后续与地图中国家匹配
df_code=pd.read_excel("Country code.xlsx",sheet_name='Country code_ETVI')
df=pd.merge(df,df_code,on='Code',how='left')

list_name=['Vulnerability','Sensitivity','Exposure','Adaptive']

##绘制地图
for name in list_name:
    
    value = df['R_'+name].tolist()
    
    attr = df['CountryCode'].tolist()
    
    #将地图中的国家名转为ISO code,方便后续与ETVI data中国家匹配
    df_map_code=pd.read_excel("Country code.xlsx",sheet_name='Country code_Map')
    suoxie=df_map_code[['Code','CountryCode']]
    name_map = suoxie.set_index('Code').to_dict()['CountryCode']
    
    #可以选择在地图中显示每个国家的三维码，所以这里做了一个国家名字匹配对应的name_map
    map0 = Map(init_opts=opts.InitOpts(width="1000px", height="350px", bg_color="white"))
    map0.add("世界地图", data_pair = [list(z) for z in zip(attr, value)], maptype="world",is_map_symbol_show=False,name_map=name_map,
        #layout_center=["45%", "50%"],  # 地图中心位置（X%, Y%），默认是 ["50%", "50%"]
        layout_size="100%"              # 地图大小，默认约85%，可以调小放大
    ) 
    #map0.set_series_opts(label_opts=opts.LabelOpts(is_show=True))  #此处控制在地图上是否显示红点，data_city中有的市名才会在地图中显示红点
    map0.set_series_opts(
        label_opts=options.LabelOpts(is_show=False)
                                             
    )   
    
    if name == 'Vulnerability':
        value = df['R_' + name].tolist()
        pieces = get_pieces_from_quantiles(value, name)
    elif name == 'Sensitivity':
        value = df['R_' + name].tolist()
        pieces = get_pieces_from_quantiles(value, name)
    elif name == 'Adaptive':
        value = df['R_' + name].tolist()
        pieces = get_pieces_from_quantiles(value, name)
    elif name == 'Exposure':
        value = df['R_' + name].tolist()
        pieces = get_pieces_from_quantiles(value, name)

    visualmap_opts = opts.VisualMapOpts(
        is_show=True,  # 一定要 True，地图才会被正确着色
        is_piecewise=True,
        pieces=pieces,
        orient='vertical',
        pos_left='82.5%',
        pos_top='29%',
        item_width=0.1,       # 隐藏自带色块（设为0），这里选择更flexible的自己调节legend的位置和大小
        item_height=0.1,      # 同上
        textstyle_opts=opts.TextStyleOpts(color="transparent"),  # 隐藏标签
        border_color="white",  
        background_color="white"  # 避免有残留框线
    )

    # 对pieces按min排序
    pieces_sorted = sorted(pieces, key=lambda x: x["min"])

    # 位置参数（让图例紧跟 title 下面）
    left_px = 900          
    start_top_px = 105      
    gap_top_px = 24
    block_width = 22
    block_height = 13
    
    # manual legend
    graphic_items = []
    for i, piece in enumerate(pieces_sorted):
        top_position = start_top_px + i * gap_top_px
    
        # legend-color boxes
        graphic_items.append({
            "type": "rect",
            "left": f"{left_px - 20}px",  # 色块放左边
            "top": f"{top_position}px",
            "shape": {
                "width": block_width,
                "height": block_height
            },
            "style": {
                "fill": piece["color"],
                "stroke": "black",  # 可选：边框颜色
                "lineWidth": 0.1     # 可选：边框宽度
            },
            "z": 100,
        })
    
        # legend-text
        graphic_items.append({
            "type": "text",
            "left": f"{left_px+10}px",
            "top": f"{top_position-2}px",
            "style": {
                "text": piece["label"],
                "fill": "black",
                "font": "16px Times New Roman",
            },
            "z": 100,
        })
        
    if name=='Adaptive':
        name='Adaptive Capacity'
    
    ## legend-title
    graphic_items.append({
        "type": "text",
        "right": "4%",          # 左上角，稍微偏左一点
        "top": "21%",           # 距离顶部2%
        "style": {
            "text": name,
            "fill": "black",
            "font": "bold 20px Times New Roman",
            "textAlign": "center",
        },
        "z": 100,
    })
    
    ## main title
    graphic_items.append({
        "type": "text",
        "left": "center",  # 水平居中
        "top": "2%",       # 距离图形上方 2%
        "style": {
            "text": name,  
            "fill": "black",
            "font": "bold 24px Times New Roman",
            "textAlign": "center",
        },
        "z": 100,
    })
    
    ## Serial number
    
    if name == 'Vulnerability':
        label = 'a'
    elif name == 'Exposure':
        label = 'b'
    elif name == 'Sensitivity':
        label = 'c'
    elif name == 'Adaptive Capacity':
        label = 'd'
    
    graphic_items.append({
        "type": "text",
        "left": "18%",          # 左上角，稍微偏左一点
        "top": "4%",           # 距离顶部2%
        "style": {
            "text": label,
            "fill": "black",
            "font": "bold 28px Times New Roman",
            "textAlign": "left",
        },
        "z": 100,
    })

    map0.set_global_opts(
        visualmap_opts=visualmap_opts,
        graphic_opts=graphic_items,
        legend_opts=opts.LegendOpts(is_show=False),

    )
    
    html_file = f"Figure_2//Figure 2-{name}.html"
    png_file = f"Figure_2//Figure 2-{name}.png"
    save_file = f"Figure_2//Figure 2-{name}.png"
    
    # 先生成截图
    map0.render(html_file)
    make_snapshot(snapshot, html_file, png_file, pixel_ratio=3)
    
    # 打开截图裁剪上下40像素
    img = Image.open(png_file)
    width, height = img.size
    cropped = img.crop((250, 20, width, height - 55))  # 左，上，右，下
    
    # 保存裁剪后的图片（覆盖原图）
    cropped.save(save_file)
 
    

##3. 拼接Figure 2

#############################################################################
##Merge images

# 读取图片
img1 = Image.open("Figure_2//Figure 2-Vulnerability.png")
img2 = Image.open("Figure_2//Figure 2-Exposure.png")
img3 = Image.open("Figure_2//Figure 2-Sensitivity.png")
img4 = Image.open("Figure_2//Figure 2-Adaptive Capacity.png")

imgs = [img1, img2, img3, img4]

# 计算新图尺寸
width = max(img.width for img in imgs)
gap = 0  # 间隔像素，如需间隔改这里
height = sum(img.height for img in imgs) + gap * (len(imgs) - 1)

# 创建新图
new_img = Image.new('RGB', (width, height), (255, 255, 255))

# 拼接
y_offset = 0
for img in imgs:
    new_img.paste(img, (0, y_offset))
    y_offset += img.height + gap

# 保存
new_img.save('Figure_2//Combined_Figure 2.png')

    
    