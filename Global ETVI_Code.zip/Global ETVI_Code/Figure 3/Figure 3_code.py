import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


font = {'family': 'Times New Roman'}
plt.rc('font', **font)

# 读取数据
Index_score_data = pd.read_csv('2025-07-20 Vulnerability_index_score.csv')
Index_score_data.index = Index_score_data['Code']
Index_score_data = Index_score_data.iloc[:, 2:]

# 按每列的中位数排序列顺序
Index_score_data = Index_score_data.loc[Index_score_data.median(axis=1).sort_values().index, :]

Index_rank_data = pd.read_csv('2025-07-20 Vulnerability_index_rank.csv')
Index_rank_data.index = Index_rank_data['Code']
Index_rank_data = Index_rank_data.iloc[:, 2:]

# 按每列的中位数排序列顺序
Index_rank_data = Index_rank_data.loc[Index_rank_data.median(axis=1).sort_values().index, :]


# 设置 boxplot 样式（去掉 mean 和 median，只保留 box 形状）
boxprops = dict(linestyle='--', linewidth=1, color='black', facecolor='white')

# 转置数据，列是国家，行为指标名
boxplot_data = Index_score_data.T

# 提取三条参考线数据
baseline = Index_score_data['Baseline']
percentile_1 = Index_score_data['1%分位数']
percentile_5 = Index_score_data['5%分位数']



# 开始画图
box_width = 0.75  # 与 plt.boxplot 中 widths 保持一致
half_width = box_width / 2
plt.figure(figsize=(32, 9))
plt.boxplot(
    boxplot_data,
    whis=1.5,
    patch_artist=True,
    widths=box_width,
    showmeans=False,
    showfliers=False,
    boxprops=boxprops,
    medianprops=dict(color='none'),
    labels=Index_score_data.index
)

# 添加自定义线（baseline / 1% / 5%）与箱体等宽
positions = range(1, len(boxplot_data.columns) + 1)
for i, pos in enumerate(positions):
    # 1%分位数 - 蓝色圆点
    plt.plot(pos, percentile_1[i], color='#1f77b4', marker='o', markersize=4)
    # 5%分位数 - 绿色三角
    plt.plot(pos, percentile_5[i], color='green', marker='o', markersize=4)
    # baseline - 橙色圆点
    plt.plot(pos, baseline[i], color='orange', marker='o', markersize=5)

# 添加自定义辅助线代替 grid
n = len(boxplot_data.columns)
for xv in np.linspace(1, n,  n):
    plt.axvline(x=xv, color='lightgray', linestyle='--', linewidth=0.8, alpha=0.5, zorder=0)
ymin, ymax = plt.ylim()
for yv in np.linspace(ymin, ymax, 30):
    plt.axhline(y=yv, color='lightgray', linestyle='--', linewidth=0.8, alpha=0.5, zorder=0)

# 美化图形
#plt.grid(axis='y', ls='--', alpha=0.5, linewidth=2)
plt.xlabel('Cities', fontsize=30, labelpad=10, weight='bold')

plt.title('EVTI Score in 2023',fontsize=38,pad=12, fontweight='bold')
plt.ylabel('Score', fontsize=30, labelpad=5, weight='bold')
plt.xticks(fontsize=10, rotation='vertical')
plt.yticks(fontsize=20)
plt.xticks([], [])

fig = plt.gcf()  # 获取当前图形对象
fig.text(0.1, 0.95, 'a', fontsize=40, fontweight='bold', va='top', ha='left')

plt.savefig('Figure_3//Vulnerability index score.png', dpi=600, bbox_inches='tight')
plt.show()
plt.close('all')



# 画Index rank箱型图
# boxplot 数据转置（列是国家）
boxplot_data = Index_rank_data.T

# 提取三类参考线
baseline = Index_rank_data['Baseline']
percentile_1 = Index_rank_data['1%分位数']
percentile_5 = Index_rank_data['5%分位数']

# 宽度控制
box_width = 0.75
half_width = box_width / 2

# 开始画图
plt.figure(figsize=(32, 9))
plt.boxplot(
    boxplot_data,
    whis=1.5,
    patch_artist=True,
    widths=box_width,
    showmeans=False,              # 不显示 mean
    showfliers=False,             # 不显示异常值
    boxprops=boxprops,
    medianprops=dict(color='none'),  # 隐藏中位数线
    labels=Index_rank_data.index
)

# 添加自定义线和点
positions = range(1, len(boxplot_data.columns) + 1)
for i, pos in enumerate(positions):
    # 1%分位数 - 蓝色圆点
    plt.plot(pos, percentile_1[i], color='#1f77b4', marker='o', markersize=4)
    # 5%分位数 - 绿色三角
    plt.plot(pos, percentile_5[i], color='green', marker='o', markersize=4)
    # baseline - 橙色圆点
    plt.plot(pos, baseline[i], color='orange', marker='o', markersize=5)

# 图形美化
#plt.grid(axis='both', ls='--', alpha=0.5, linewidth=2)

plt.title('EVTI Rank in 2023', fontsize=38,pad=12, fontweight='bold')

plt.xlabel('Cities', fontsize=30, labelpad=10, weight='bold')
plt.ylabel('Rank',fontsize=30, labelpad=5, weight='bold')
plt.xticks(fontsize=10, rotation='vertical')
plt.yticks(fontsize=20)
plt.xticks([], [])

# 添加自定义辅助线代替 grid
n = len(boxplot_data.columns)
# 添加等间距的纵向辅助线（垂直线，覆盖 x 轴）
for xv in np.linspace(1, n, n):
    plt.axvline(x=xv, color='lightgray', linestyle='--', linewidth=0.8, alpha=0.5, zorder=0)
ymin, ymax = plt.ylim()
# 添加等间距的横向辅助线（水平线，覆盖 y 轴）
for yv in np.linspace(ymin, ymax, 30):
    plt.axhline(y=yv, color='lightgray', linestyle='--', linewidth=0.8, alpha=0.5, zorder=0)

fig = plt.gcf()  # 获取当前图形对象
fig.text(0.1, 0.95, 'b', fontsize=40, fontweight='bold', va='top', ha='left')
plt.savefig('Figure_3\\Vulnerability index rank.png', dpi=600, bbox_inches='tight')

plt.show()
plt.close('all')

# merge figures
from PIL import Image

# 读取图片
img1 = Image.open('Figure_3\\Vulnerability index score.png')
img2 = Image.open('Figure_3\\Vulnerability index rank.png')

# 计算拼接后图像的尺寸
width = max(img1.width, img2.width)
height = img1.height + img2.height

# 创建一个新图，大小是两张图高度相加，宽度取最大
new_img = Image.new('RGB', (width, height), (255, 255, 255))

# 把第一张图粘贴到新图顶部
new_img.paste(img1, (0, 0))
# 把第二张图粘贴到第一张图下面
# 粘贴第二张图，位置向下移动gap
gap = 38  # 你想要的间距高度，单位：像素
new_img.paste(img2, (0, img1.height + gap))

# 保存拼接后的图片
new_img.save('Figure_3//combined_vulnerability_index.png')

